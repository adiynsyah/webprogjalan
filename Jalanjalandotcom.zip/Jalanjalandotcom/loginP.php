<?php 
include("connection.php");
$user=$_POST['txtUsername'];
$pass=$_POST['txtPassword'];
$enc_pass=sha1($pass);

$Q = mysql_query("select * from user where Username='$user' and Password='$enc_pass'") or die(mysql_error());
$show = mysql_fetch_array($Q);

$count = mysql_num_rows($Q);

if($count==1){
session_start();
$_SESSION['Username']=$show['UserID'];
	echo"<script>document.location='index.php'</script>";
}
else{
	echo"<script>alert('Wrong username or password!!');document.location='login.php'</script>";
}
?>