-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2017 at 01:39 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jalanjalan`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`CatID` int(11) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Link` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CatID`, `Category`, `Link`) VALUES
(1, 'Forum Diskusi', 'forum_diskusi.php'),
(2, 'Forum Jalan-Jalan', 'forum_jalan.php'),
(3, 'Forum Jasa', 'forum_jasa.php');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE IF NOT EXISTS `replies` (
`ReplyID` int(11) NOT NULL,
  `ReplyContent` varchar(5000) NOT NULL,
  `ReplyDate` datetime NOT NULL,
  `ReplyThread` int(11) NOT NULL,
  `ReplyBy` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`ReplyID`, `ReplyContent`, `ReplyDate`, `ReplyThread`, `ReplyBy`) VALUES
(7, 'Say no to pertamax.. jangan kaya forum sebelah lololol..\r\n\r\nAyoooo gan!! gas terus.. mau ke pantai mana nih? pantai semeru asik tuh kayaknya.. eh semeru mah gunung yaa.. ehhehe jadi malu.. gapapa lah yang penting kuy lah kuy kuy kuyyy.. yang cewe ikuuut donng.. aku kesepian nih', '2016-11-30 17:31:13', 15, 3),
(8, 'Wkwkwk forum sebelah yang mana gan? kurang paham nih..\r\n\r\nettdaah ada-ada aja si agan mah pake ngajak pantai semeru segala', '2016-11-30 17:35:26', 15, 2),
(13, 'Apa aja boleeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeh', '2016-11-30 22:15:27', 9, 2),
(15, 'test', '2016-11-30 22:15:55', 9, 2),
(16, 'cacat dah lu', '2016-12-02 09:07:17', 9, 5),
(17, 'woi respomsive kek website nya kampret dah', '2016-12-02 09:08:27', 6, 5),
(18, 'gw beli satu boleh ga gan? hehe', '2016-12-02 09:09:47', 17, 5),
(19, 'WOIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII', '2016-12-03 07:02:59', 9, 5),
(20, '', '2016-12-03 07:11:05', 9, 5),
(21, 'Kok engga resposive sihh anejgn dahh', '2016-12-03 07:18:04', 6, 5),
(22, 'WOIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII', '2016-12-03 07:20:43', 7, 5),
(23, 'Say no to pertamax.. jangan kaya forum sebelah lololol.. Ayoooo gan!! gas terus.. mau ke pantai mana nih? pantai semeru asik tuh kayaknya.. eh semeru mah gunung yaa.. ehhehe jadi malu.. gapapa lah yang penting kuy lah kuy kuy kuyyy.. yang cewe ikuuut donng.. aku kesepian nih', '2016-12-03 07:22:04', 6, 5),
(24, 'cacat dah lu', '2016-12-03 07:27:34', 8, 5),
(27, 'cacat dah lu', '2016-12-05 10:30:44', 19, 6),
(28, 'ASD', '2016-12-05 10:55:24', 20, 7),
(29, 'apa nih?', '2017-01-13 02:02:14', 21, 5),
(30, 'singa?', '2017-01-13 02:07:07', 20, 5),
(31, 'murah ga si?', '2017-01-13 02:09:07', 17, 5);

-- --------------------------------------------------------

--
-- Table structure for table `thread`
--

CREATE TABLE IF NOT EXISTS `thread` (
`ThreadID` int(11) NOT NULL,
  `ThreadSubject` varchar(300) NOT NULL,
  `ThreadDesc` varchar(5000) NOT NULL,
  `ThreadDate` datetime NOT NULL,
  `ThreadView` int(11) NOT NULL,
  `ThreadCat` int(11) NOT NULL,
  `ThreadBy` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `thread`
--

INSERT INTO `thread` (`ThreadID`, `ThreadSubject`, `ThreadDesc`, `ThreadDate`, `ThreadView`, `ThreadCat`, `ThreadBy`) VALUES
(6, 'Thread Diskusi', 'diskusi diskusi diskusi', '2016-11-29 05:15:25', 0, 1, 2),
(7, 'Thread Jalan-Jalan', 'jalan jalan jalan jalan jalan jalan', '2016-11-29 02:28:05', 0, 2, 3),
(8, 'Thread Jasa', 'jasa jasa jasa jasa jasa', '2016-11-29 14:24:08', 0, 3, 2),
(9, 'Diskusi apa nih?', 'Kepulauan Raja Ampat merupakan destinasi wisata yang terletak di wilayah Papua. Wisata ini sudah dikenal oleh seluruh dunia karena keelokan alamnya yang sangat mempesona. Salah satu bentuk kepopuleran objek wisata Raja Ampat adalah dengan adanya film dokumenter yang dibuat oleh Avant Premiere yang berjudul ” Edis Paradise 3 “, dimana dalam film tersebut menceritakan keindahan alam bawah laut Raja Ampat yang berada di kawasan Papua, yang mana wisata ini juga dijuluki sebagi kawasan Amazon Lautan Dunia.  Julukan tersebut diberikan karena letak dari tempat wisata ini yang berada dipusat segitiga karang dunia. Wisata Kepulauan Raja Ampat berada dikawasan teritorial Papua Barat, yang merupakan sebuah gugusan pulau yang tersebar dengan jumlahnya berkisar 610 pulau, akan tetapi hanya ada 35 pulau yang dihuni oleh penduduk.  Comment |   Like |   Unlike   Write a comment..   Dodo Julukan tersebut diberikan karena letak dari tempat wisata ini yang berada dipusat segitiga karang dunia. Wisata Kepulauan Raja Ampat berada dikawasan teritorial Papua Barat, yang merupakan sebuah gugusan pulau yang tersebar dengan jumlahnya berkisar 610 pulau, akan tetapi hanya ada 35 pulau yang dihuni oleh penduduk.|karang dunia. Wisata Kepulauan Raja Ampat berada dikawasan teritorial Papua Barat, yang merupakan sebuah gugusan pulau yang tersebar dengan jumlahnya berkisar 610 pulau, akan tetapi hanya ada 35 pulau yang dihuni oleh penduduk. Like . Unlike .  5 .  10 User avatar  Adiyansyah  Binusian   Posts: 16 Joined: Fri Aprl 2016 06:00 am', '2016-11-30 12:28:22', 0, 1, 3),
(15, 'Jalan yuuk', 'Pantai nyoook!!!', '2016-11-30 17:28:13', 0, 2, 2),
(17, 'Jual aneka barang hiking', 'Minat pm gan', '2016-11-30 17:31:37', 0, 3, 2),
(19, 'KE MENADO YUK!', 'SERU LOH', '2016-12-05 10:30:23', 0, 2, 6),
(20, 'SINGAPURE ITU INDAAH', 'ASDAOSJDOASIJDPIAJSDPJIASPDJPAJSDPPASJPJ\r\nASDASDAOSJDOASIJDPIAJSDPJIASPDJPAJSDPPASJPJ', '2016-12-05 10:55:05', 0, 2, 7),
(21, 'MENADO KEREN LOH', 'TERSERAH!', '2017-01-13 02:01:33', 0, 1, 8);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`UserID` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Fullname` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Bio` varchar(500) DEFAULT NULL,
  `ProfilePict` varchar(500) DEFAULT NULL,
  `Role` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Fullname`, `Email`, `Bio`, `ProfilePict`, `Role`) VALUES
(2, 'danssul', 'asd', 'Danny Sulistiyo', 'admin_danny@yahoo.com', 'Its my 1st bio :D', NULL, 1),
(3, 'DummyTest', 'ganteng252', 'Dummy Test', 'testdummy@yahoo.com', NULL, NULL, 1),
(5, 'apiputra', 'c7bd812400dfef1a8b7e6e5d1d507726d4ceb7f0', 'adiyansyah', 'adiyansyah@gmail.com', NULL, NULL, 1),
(6, 'jona', 'c7bd812400dfef1a8b7e6e5d1d507726d4ceb7f0', 'JonaJoni', 'jona@gmail.com', NULL, NULL, 1),
(7, 'adrian', 'c7bd812400dfef1a8b7e6e5d1d507726d4ceb7f0', 'adrianalbert', 'adrian@gmail.com', NULL, NULL, 1),
(8, 'adrian123', '78bf7d812c6f5031d2f5bdb2611250a5642918fe', 'Adrian Albert Allan', 'adrian@gmail.com', NULL, NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`CatID`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
 ADD PRIMARY KEY (`ReplyID`), ADD KEY `ReplyThread` (`ReplyThread`), ADD KEY `ReplyBy` (`ReplyBy`);

--
-- Indexes for table `thread`
--
ALTER TABLE `thread`
 ADD PRIMARY KEY (`ThreadID`), ADD KEY `ThreadCat` (`ThreadCat`), ADD KEY `ThreadBy` (`ThreadBy`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
MODIFY `CatID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
MODIFY `ReplyID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `thread`
--
ALTER TABLE `thread`
MODIFY `ThreadID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `replies`
--
ALTER TABLE `replies`
ADD CONSTRAINT `replies_ibfk_1` FOREIGN KEY (`ReplyBy`) REFERENCES `user` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `replies_ibfk_2` FOREIGN KEY (`ReplyThread`) REFERENCES `thread` (`ThreadID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `thread`
--
ALTER TABLE `thread`
ADD CONSTRAINT `thread_ibfk_1` FOREIGN KEY (`ThreadBy`) REFERENCES `user` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `thread_ibfk_2` FOREIGN KEY (`ThreadCat`) REFERENCES `categories` (`CatID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
