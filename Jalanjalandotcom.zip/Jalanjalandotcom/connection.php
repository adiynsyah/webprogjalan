<?php
mysql_connect("localhost","root","")or die("mysql connect wrong spelling | ".mysql_error());
mysql_select_db("jalanjalan");
?>