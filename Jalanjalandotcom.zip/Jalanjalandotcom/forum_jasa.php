<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Forum Jasa</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<link rel="stylesheet" type="text/css" href="style/style_main-forum.css">
</head>
<script>
		function createPost(){
			var cat = "3";
			window.location.href = "newthread.php?cat=" + cat;
		}
	</script>
<body>
	<div id="header">
		<div id="header-inner" class="inner-block">
			<div id="logo">
				<img src="logo/logo.png">
			</div>
			<div id="main_nav">
				<ul>
					<li><a href="index.php" class="hom">Home</a></li>
					<?php
						if(isset($_SESSION['Username'])){
							$user=$_SESSION['Username'];
							$Q = mysql_query("SELECT * FROM user WHERE UserID='$user'")or die(mysql_error());
							$rs = mysql_fetch_array($Q);
							$id = $rs['Username'];
							echo"<li><a href='viewprofile.php?user=$id' class='hom'>Profile</a></li>";
							echo"<li><a href='logout.php' class='logout'>Logout</a></li>";
						}
						else{
							echo"<li><a href='login.php' class='login'>Login</a></li>";
						}
					?>
				</ul>
			</div>
		</div>
	</div>
	
	<div class="forum">
		<nav class="nav">
		<ul>
			<h1>Choose Forum!</h1>
				<?php
					$showCat = mysql_query("select Category,Link from categories")or die(mysql_error());
					while($show=mysql_fetch_array($showCat)){
						$cat = $show['Category'];
						$link = $show['Link'];
						echo"<li><a href='$link'>$cat</a></li>";
					}
				?>
		</ul>
		</nav>

		<article class="article">
			<div class="buttons">
				<a onclick="createPost()">Post a new topic</a>
			</div>
			<!--
			<div class="search-box">
				<fieldset>
					<input type="text" id="key" placeholder="Search this forum..">
					<div class="go"><a href=""><img src="icon/icon-forum/search.png" height="15px" width="15px"></a></div>
				</fieldset>
			</div>
			<div id="center">
				<ul class="pagination">
					<li><a href="#">«</a></li>
					<li><a class="active" href="#">1</a></li>
					<li><a href="#">2</a></li>
					<li><a href="#">»</a></li>
				</ul>
			</div>
			-->
			<table>
				  <tr id="head">
				    <td class="topic">Topics</td>
				    <td class="rep">Replies</td>
				    <td class="view">Views</td>
				    <td class="last">Last Post</td>  
				  </tr>
				  <?php
						$showThread1 = mysql_query("SELECT
													thread.ThreadSubject,
													USER.Username,
													thread.ThreadDate,
													thread.ThreadView,
													thread.ThreadID
													FROM thread
													JOIN USER ON USER.UserID = thread.ThreadBy
													WHERE ThreadCat = 3
													ORDER BY ThreadID DESC")or die(mysql_error());
						while($show1=mysql_fetch_array($showThread1)){
							$title = $show1[0];
							$postBy = $show1[1];
							$postDate = $show1[2];
							$view = $show1[3];
							$threadID = $show1[4];
							$date = date_create($postDate);
						
				  ?>
				  <tr id="content">
				  	<td class="con_topic"><p class="top"><a href="ThreadViewReplay.php?threadID=<?php echo $threadID ?>"><?php echo $title; ?></a></p>
					 by <a href="viewprofile.php?user=<?php echo $postBy ?>" class="by"><?php echo $postBy; ?></a> on <?php echo date_format($date, 'D, d M Y H:i A'); ?>
				  	</td>
				  	<td class="con_rep">N/A</td>
				  	<td class="con_view"><?php echo $view; ?></td>
				  	<!--<td class="con_last">by <a href="viewprofile.php" class="last_name">Adiyansyah</a><br>Monday Fri Aprl 2016 16:00 pm</td>-->
					<td class="con_last">N/A</td>
				  </tr>
				  <?php } ?>
			</table>
		</article>	
	</div>
	<footer class="second">
			<p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
		</footer>
	</footer>
</body>

</html>