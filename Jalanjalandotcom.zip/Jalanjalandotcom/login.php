<?php
if(isset($_SESSION['Username'])){
	echo"<script>document.location='index.php'<script>";
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="style/style-login.css">
</head>

<body>
  <div id="header">
    <div id="header-inner" class="inner-block">
      <div id="logo">
        <img src="logo/logo.png">
      </div>
      <div id="main_nav">
        <ul>
          <li><a href="index.php" class="hom">Home</a></li>
          <li><a href="viewprofile.php" class="prof">Profile</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="login-page">
    <div class="form">
      <form class="login-form" method="post" action="loginP.php">
        <input type="text" placeholder="username" name="txtUsername">
        <input type="password" placeholder="password" name="txtPassword">
        <input class="button_login" type="submit" value="LOGIN">
        <div class="message">Not registered? <a href="create-account.php">Create Account</a></div>
      </form>
    </div>
  </div>
  <footer class="second">
    <p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
  </footer>
</body>

</html>