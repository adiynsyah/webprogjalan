<?php
	include('connection.php');
	include('session.php');
	$id = $_SESSION['Username'];
	$username = $_POST['txtUsername'];
	$pass = $_POST['txtPass'];
	$bio = $_POST['txtBio'];
	$encPass = sha1($pass);
	
	$Q = mysql_query("UPDATE user SET
					  Username='$username', Password='$encPass', Bio='$bio' WHERE UserID = '$id'")or die(mysql_error());
	if($Q){
		echo"<script>alert('Profile updated');document.location='viewprofile.php?user=$username'</script>";
	}
?>