<?php
include("connection.php");

$name = $_POST['txtName'];
$mail = $_POST['txtMail'];
$username = $_POST['txtUsername'];
$pass = $_POST['txtPass'];
$agree = $_POST['chkAgree'];
$enc_pass = sha1($pass);

$cekdb = mysql_query("select * from user where Username='$username'") or die(mysql_error());
$count= mysql_num_rows($cekdb);
if($count == 1){
?>
<script>alert('Username already exists.');document.location='create-account.php'</script>
<?php
}
else if($name==""){
	echo "<script>alert('Fullname must be filled.');document.location='create-account.php'</script>";
}
else if($mail==""){
	echo "<script>alert('Email must be filled.');document.location='create-account.php'</script>";
}
else if(!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
	echo "<script>alert('Invalid email format.');document.location='create-account.php'</script>";
}
else if($username==""){
	echo "<script>alert('Username must be filled.');document.location='create-account.php'</script>";
}
else if(strlen($username)<4 || strlen($username)>15){
	echo "<script>alert('Username length must between 4 - 15 characters.');document.location='create-account.php'</script>";
}
else if($pass==""){
	echo "<script>alert('Password must be filled.');document.location='create-account.php'</script>";
}
else if(strlen($pass)<10||strlen($pass)>20){
	echo "<script>alert('Password must between 10 - 20 characters.');document.location='create-account.php'</script>";
}
else if($agree==""){
	echo "<script>alert('Please check the agreement.');document.location='create-account.php'</script>";
}
else{
	mysql_query("insert into user(Username,Password,Fullname,Email,Role) values ('$username','$enc_pass','$name','$mail',1)") or die(mysql_error());
	echo"<script>alert('Registration Successful!');document.location='index.php'</script>";
}
?>