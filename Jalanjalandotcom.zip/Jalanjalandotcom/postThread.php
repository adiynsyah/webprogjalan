<?php
include("connection.php");
include("session.php");

$subject = $_POST['txtSubject'];
$post = $_POST['txtPost'];
$user = $_SESSION['Username'];
$cat = $_POST['cat'];
$date = date("Y-m-d H:i:s");

mysql_query("INSERT INTO thread(ThreadSubject,ThreadDesc,ThreadDate,ThreadView,ThreadCat,ThreadBy) VALUES 
             ('$subject','$post','$date',0,'$cat','$user')") or die(mysql_error());

echo "<script>alert('Post Added!');</script>";
if($cat=1) echo"<script>document.location='forum_diskusi.php';</script>";
else if($cat=2) echo"<script>document.location='forum_jalan.php';</script>";
else if($cat=3) echo"<script>document.location='forum_jasa.php';</script>";
?>