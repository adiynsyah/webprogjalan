<?php
session_start();
if($_SESSION['Username']==""){
?>

<script>
	alert("You must login first");
	document.location='login.php';
</script>
<?php } ?>