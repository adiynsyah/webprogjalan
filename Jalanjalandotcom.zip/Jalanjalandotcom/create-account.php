<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Create-Account</title>   
  <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
  <link rel="stylesheet" type="text/css" href="style/style-create-account.css">
</head>

<body>
  <div id="header">
    <div id="header-inner" class="inner-block">
      <div id="logo">
        <img src="logo/logo.png">
      </div>
      <div id="main_nav">
        <ul>
          <li><a href="index.php" class="hom">Home</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="main-create">
      <div class="inner-create">
        <form action="signup.php" method="post">        
            <input type="text" placeholder="Fullname" name="txtName">
            <input type="text" placeholder="Email" name="txtMail">
            <input type="text" placeholder="Username" name="txtUsername">
            <input type="password" placeholder="Password" name="txtPass">
           

            <div class="check">
              <input type="checkbox" name="chkAgree">
              <div class="agree">I Agree with terms & conditions</div>
            </div>        
            
            <input type="submit" class="button_create" value="Create Account">
        </form>
      </div>
  </div>
  <footer class="second">
    <p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
  </footer>
</body>

</html>