<?php
	$user = $_POST['txtUserID'];
	$thread = $_POST['txtThreadID'];
	echo $user."asd".$thread;
?>