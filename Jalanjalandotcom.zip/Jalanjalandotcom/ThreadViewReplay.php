<?php
session_start();
include('connection.php');
$id = $_GET['threadID'];

$showPost = mysql_query("SELECT * FROM thread JOIN user ON user.userID = thread.ThreadBy WHERE ThreadID='$id'")or die(mysql_error());
		$rs = mysql_fetch_array($showPost);
		$title = $rs['ThreadSubject'];
		$post = $rs['ThreadDesc'];
		$postDate = $rs['ThreadDate'];
		$date = date_create($postDate);
		$user = $rs['Username'];

$showUser = mysql_query("SELECT * FROM user WHERE UserID")or die(mysql_error());
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=divice-width, initial-scale=1.0"/>
	<link rel="stylesheet" type="text/css" href="style/style_ThreadViewReplay.css">
</head>

<body>
	<div id="header">
		<div id="header-inner" class="inner-block">
			<div id="logo">
				<img src="logo/logo.png">
			</div>
			<div id="main_nav">
				<ul>
					<?php
						if(isset($_SESSION['Username'])){
							echo"<li><a href='logout.php' class='log'>Logout</a></li>";
						}
						else{
							echo"<li><a href='login.php' class='hom'>Login</a></li>";
						}
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="top-pagination">
		<div class="inner inline-block">
			<ul class="nav-pagination">
				<li> 
					<a href="forum_diskusi.php">Forum Jalan-jalan</a> <b>></b>
					<a href="#"><?php echo $title ?></a>
				</li>
			</ul>
		</div>
	</div>
	<div id="page-body" class="inline-block">
		<h1><?php echo $title ?></h1>
		<div id="page-body-inner">
			<div class="clear"></div>
			<div class="post">
				<div class="inner">
				<dl id="profil3" class="postprofile">
						<dt>
							<img src="img/img-forum/avatar_edit.png" width="100" height="100" alt="User avatar">
							<br>
							<div class="username">
								<a href="viewprofile.php?user=<?php echo $user ?>" class="by"><?php echo $user ?></a>
							</div>
						</dt>
						<dd>Binusian</dd>
						<dd>&nbsp;</dd>
						<dd><strong style="color:black; font-weight: bold;">Posts:</strong> 16</dd>
					</dl>
					<br><br>
					<div class="postbody">
						<h3 class="first"><img src="icon/icon-forum/crown.png" style="width: 14px;height:16px"><a href="#"><?php echo $title ?></a></h3>
						<p class="author">by <a href="#" class="by"><?php echo $user ?></a> » <?php echo date_format($date, 'D, d M Y H:i A'); ?></p>
						<div class="content">
						<?php echo $post ?>
						</div>
						<!--
							<div id="sig3" class="signature">
								<img src="icon/icon-forum/chat.png" width="18" height="18"> Comment  |  <img src="icon/icon-forum/like.png" width="18" height="18"> Like  |  <img src="icon/icon-forum/unlike.png" width="18" height="18"> Unlike
							</div>
						-->
						<div id="main-coment">
							<div class="body-coment">
								<div class="profilcoment">
									<div class="iconcoment">
										<a href="#"><img src="img/img-forum/avatar_edit.png" width="40px" height="40px"></a>
									</div>
								</div>
								
								<div class="typecoment">
									<form method="post" action="postComment.php">
										<fieldset>
											<input class="co" type="text" name ="txtComment" placeholder="Write a comment..">
											<input type="hidden" name="txtUserID" value="<?php echo $_SESSION['Username'] ?>">
											<input type="hidden" name="txtThreadID" value="<?php echo $id ?>">
										</fieldset>
										<div class="buttons">
											<div class="reply-icon">
												<input type="submit" value="POST">
											</div>					
										</div>
									</form>									
								</div>
								
							</div>
							<div class="topic-actions">
				<div class="search-box">
				</div>
						    </div>
							
							
							
						
						<?php
							$queryComment = mysql_query("SELECT * FROM replies
														 JOIN user ON user.UserID = replies.ReplyBy WHERE ReplyThread='$id'
														 ORDER BY ReplyID")or die(mysql_error());
							while($showComment = mysql_fetch_array($queryComment)){
								$userC = $showComment['Username'];
								$postC = $showComment['ReplyContent'];
							
						?>
						<div class="body-coment-answare">
								<div class="profilansware">
									<div class="iconansware">
										<a href="#"><img src="img/img-forum/avatar_edit.png" width="40px" height="40px"></a>
									</div>
								</div>
								
								<div class="answare">
									<a href="viewprofile.php?user=<?php echo $userC ?>" class="byansware"><?php echo $userC ?></a><br> 
									<?php echo $postC ?>
									<!--
									<div class="bottom-answare">
										<a href="#">Like</a> . <a href="#">Unlike</a> . <img src="icon/icon-forum/like.png" width="18" height="18"> 5 . <img src="icon/icon-forum/unlike.png" width="18" height="18"> 10
									</div>
									-->
								</div>
						</div>
						<?php } ?>
						</div>
					</div>
					
					<div class="backtop">
						<a href="#"><img src="icon/icon-forum/up-arrow.png" width="18" height="18"></a>
					</div>
				</div>
			</div>	
		</div>
	</div>
	<footer class="second">
			<p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
	</footer>
</body>
</html>