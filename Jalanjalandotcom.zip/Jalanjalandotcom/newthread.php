<?php
// session_start();
include('session.php');
include('connection.php');
$cat = $_GET['cat'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>New Thread</title>
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<link rel="stylesheet" type="text/css" href="style/style_newthread.css">
</head>
<body>

<div id="header">
	<div id="header-inner" class="inner-block">
		<div id="logo">
			<img src="logo/logo.png">
		</div>
		<div id="main_nav">
			<ul>
				<li><a href="index.php" class="hom">Home</a></li>
				<?php
						if(isset($_SESSION['Username'])){
							echo"<li><a href='logout.php' class='log'>Logout</a></li>";
						}
						else{
							echo"<li><a href='login.php' class='log'>Login</a></li>";
						}
				?>
			</ul>
		</div>
	</div>
</div>

<div id="main-newthrd">
	<div class="ava">
		<img src="img/img-forum/avatar_edit.png">
		<?php
			$id = $_SESSION['Username'];
			$Q = mysql_query("SELECT Username FROM user WHERE UserID='$id'")or die(mysql_error());
			$rs = mysql_fetch_array($Q);
		?>
		<div class="view_profile"><a href="viewprofile.php?user=<?php echo $rs['Username'] ?>">View Profile</a></div>
	</div>
	
	<form method="post" action="postThread.php">
		<div class="form-newthrd">
			<div class="inner-newthrd">
				<div class="head-newthrd">Post a New Thread</div>
				<div class="body-newthrd">
					<div class="user">
						<p>Subject</p>
						<input type="text" name="txtSubject">
					</div>
					<div class="bio">				
						<div class="button-thread">						
							<!--
							<button><img src="icon/icon-forum/bold.png" width="10px" height="10px"></button>
							<button><img src="icon/icon-forum/italic.png" width="10px" height="10px"></button>
							<button><img src="icon/icon-forum/underline.png" width="10px" height="10px"></button>
							<button><img src="icon/icon-forum/left.png" width="10px" height="10px"></button>
							<button><img src="icon/icon-forum/center.png" width="10px" height="10px"></button>
							<button><img src="icon/icon-forum/right.png" width="10px" height="10px"></button>
							<button><img src="icon/icon-forum/justified.png" width="10px" height="10px"></button>
							-->
						</div>
						<textarea name="txtPost"></textarea>
						<input type="hidden" name="cat" value="<?php echo $cat ?>">
					</div>
					<input type="submit" class="submit" value="POST">
					
				</div>
			</div>
		</div>
	</form>
</div>

<footer class="second">
	<p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
</footer>

</body>
</html>