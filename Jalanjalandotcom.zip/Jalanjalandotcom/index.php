<?php 
	session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home | jalanjalan.com</title>
	<meta charset="utf-8/">
	<meta name="viewport" content="width=divice-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style-home.css">
	<script src="js/slider.js" type="text/javascript"></script>
</head>
<body>
	<header>
		<a href="index.php" id="logo"><img src="logo/logo.png"></a>
		<div id="main-nav">
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="forum_diskusi.php">Forum</a></li>
				<?php
					if(!isset($_SESSION['Username'])){
						echo"<li><a href='login.php'>Login</a></li>";
					}
					else{
						echo"<li><a href='logout.php'>Logout</a></li>";
					}
				?>
			</ul>
		</div>
	</header>
	<div id="mid">
		<div id="content">		
			<div class="slideshow_content">
					<div class="sliders fade">
						<img src="img/img-home/city_sunset.jpg">
					</div>
					<div class="sliders fade">
						<img src="img/img-home/bosnia.jpg">
					</div>
					<div class="sliders fade">
						<img src="img/img-home/tample.jpg">
					</div>
					<div class="sliders fade">
						<img src="img/img-home/eiffel_tower.jpg">
					</div>

					<a class="prev" onclick="next_slides(-1)"><</a>
					<a class="next" onclick="next_slides(1)">></a>
			</div>			
		</div>
	</div>
	<section>
		<img src="icon/icon-home/doctor.png" style="height: 250px; width: 250px;">
		<h1>Professional</h1>
		<p>Kami sangat kerja keras dan memberikan pelayanan yang memuaskan dan terbaik merupakan komitmen dan tujuan kami.</p>
	</section>
	<section>
		<img src="icon/icon-home/badge.png" style="width: 250px; height: 250px;">
		<h1>Berpengalaman dan Terpercaya</h1>
		<p>Merupakan bagian dari pengalaman tour kami sudah lebih 40 tahun kita berjalan sehingga lebih handal dan terpercaya, serta di dukung oleh 50 cabang baik dalam maupun luar negri.</p>
	</section>
	<section>
		<img src="icon/icon-home/plane.png" style="width: 250px; height: 250px;">
		<h1>Produk Travel</h1>
		<p>Kami mempunyai berbagai macam tujuan dan asal negara baik dari dalam maupun luar untuk menunjang perjalanan anda. Seperti tiket yang dapat di beli di berbagai tempat sehingga anda jadi bisa lebih mudah dan cepat dalam liburan anda.</p>
	</section>
	<div class="clear"></div>
	
	<article style="margin-left: 10px; margin-top: 20px;">
		<img src="img/img-home/world-map.jpg" style=" width:511px; height:350px;">
	</article>
	<aside>
		<h2>VISI KAMI!</h2>
		<ul class="visi">
			<li><h3>Kami akan menjadikan kualitas pelayanan tingkat tinggi</h3></li>
			<li><h3>Kami akan selalu melayani anda dengan ramah</h3></li>
			<li><h3>Customer adalah RAJA</h3></li>
			<li><h3>Kami akan membuka cabang di setiap kota tanah air</h3></li>
			<li><h3>Kami akan membuka cabang di seluruh dunia</h3></li>
		</ul>
	</aside>
	
	<div class="clear"></div>
	<div id="location">
		<section>
			<h1>Campus Anggrek</h1>
			<img src="img/img-home/angrek.jpg" style="width: 300px; height: 200px;">
			<p>Anda dapat membeli ticket dan bertemu dengan tim kami di kampus anggrek binus</p>
		</section>
		<section>
			<h1>Campus Jwc</h1>
			<img src="img/img-home/jwc.jpg" style="width: 300px; height: 200px;">
			<p>Tidak hanya di kampus anggrek kita juga dapat bertemu sekaligus beli tiket dengan tim kami di kampus Jwc Senayan binus</p>
		</section>
		<section>
			<h1>Campus Alam Sutera</h1>
			<img src="img/img-home/AlamSuteraBinus.jpg" style="width: 300px; height: 200px;">
			<p>Pusat kami berada yaitu di kampus Alam Sutera tepat nya di depan persis mall Alam Sutera</p>
		</section>
	</div>
	<footer>
		<section id="foot_info">
			<h3>Tour and Travel</h3>
			<h2>jalan-jalan.com</h2>
			<p>021-576489</p>
			Perumahan taman kencan<br> 
			no 15 jalan h.mencong<br>
			15154<br>
		</section>
		<section>
			<h3>Connect With Us</h3>
			<ul class="social">
				<li><a href="#"><img src="icon/icon-home/facebook.png"></a></li>
				<li><a href="#"><img src="icon/icon-home/youtube.png"></a></li>
				<li><a href="#"><img src="icon/icon-home/line.png"></a></li>
				<li><a href="#"><img src="icon/icon-home/google-plus.png"></a></li>
			</ul>
		</section>
		<section>
			<img src="icon/icon-home/tropical.png" style="width: 300px; height: 200px;">
		</section>
		<footer class="copy">
			<p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
		</footer>
	</footer>

</body>
</html>