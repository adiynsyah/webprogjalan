<?php
include('session.php')
?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit Profile</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<link rel="stylesheet" type="text/css" href="style/style_editprofile.css">
</head>

<body>
<div id="header">
	<div id="header-inner" class="inner-block">
		<div id="logo">
			<img src="logo/logo.png">
		</div>
		<div id="main_nav">
			<ul>
				<?php
						if(isset($_SESSION['Username'])){
							echo"<li><a href='logout.php' class='log'>Logout</a></li>";
						}
						else{
							echo"<li><a href='login.php' class='hom'>Login</a></li>";
						}
				?>
			</ul>
		</div>
	</div>
</div>
<div id="main-edit">
	<div class="ava">
		<img src="img/img-forum/avatar_edit.png">
		<div class="change_picture">Change Picture</div>
	</div>
	<div class="form-edit">
		<div class="form-inner-edit">
			<div class="form-head-edit">Profile Settings</div>
			<form method="post" action="editP.php">
				<div class="form-body-edit">
					<div class="user">
						<p>Change Username</p>
						<input type="text" name="txtUsername">
					</div>
					<div class="pass">
						<p>Change Password</p>
						<input type="password" name="txtPass">
					</div>
					<div class="bio">
						<p>Change your Bio</p>
						<textarea name="txtBio"></textarea>
					</div>
					<input type="submit" class="submit" value="SUBMIT">
				</div>
			</form>
		</div>
	</div>
</div>
<footer class="second">
	<p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
</footer>

</body>


</html>