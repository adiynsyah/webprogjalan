<?php
	session_start();
	include("connection.php");
	$user = $_GET['user'];
	$Q = mysql_query("SELECT * FROM user WHERE Username='$user'")or die(mysql_error());
	$rs = mysql_fetch_array($Q);
?>
<!DOCTYPE html>
<html>
<head>
	<title>View Profile</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<link rel="stylesheet" type="text/css" href="style/style-viewprofile.css">
</head>
<body>

<div id="header">
	<div id="header-inner" class="inner-block">
		<div id="logo">
			<a href="index.php"><img src="logo/logo.png"></a>
		</div>
		<div id="main_nav">
			<ul>
				<?php
					if(isset($_SESSION['Username'])){
						echo"<li><a href='logout.php' class='log'>Logout</a></li>";
					}
					else{
						echo"<li><a href='login.php' class='hom'>Login</a></li>";
					}
				?>
			</ul>
		</div>
	</div>
</div>

<div id="main-view">
	<div class="ava">
		<img src="img/img-forum/avatar_edit.png">
		<div class="username"><a href="" class="by"><?php echo $rs['Username'] ?></a></div>
		<?php
			if(isset($_SESSION['Username'])){
				if($rs['UserID']==$_SESSION['Username']){
					echo"<div class='but_edit'><a href='edit-profile.php'>Edit Profile</a></div>";
				}
			}
		?>
	</div>
	<div class="view-profile">
		<div class="inner-view"><br>
			<div class="head-view"><?php echo $rs['Username']?> Profile</div>
			<div class="body-view">
				<div class="fullname">
					<p>Fullname : <?php echo $rs['Fullname'] ?></p>			
				</div>
				<div class="bio">
					<p>Bio : <?php 
						if($rs['Bio']=="")echo "Bio still not set";
						else echo $rs['Bio']
					?>
					</p>					
				</div>
				
				<div class="join">
					<p>Join Since : 18 September 2016</p>					
				</div>
				
				<?php
					if(isset($_SESSION['Username'])){
						if($rs['UserID']!=$_SESSION['Username']){
							echo"<div class='submit'>Add as Friend</div>";
						}
					}
				?>
			</div>
		</div>
	</div>
	
	<div class="myfriend">
		<div class="inner-myfriend">
			<div class="head-myfriend">My Friends</div>
			<div class="body-myfriend">
			empty
			<!-- 	<div class="friend1">
					<img src="img/img-forum/ahmad.jpg" width="75px" height="75px"><a href="" class="af1">Ahmad</a>
					<div class="but_Add">Add</div>
				</div>
				<div class="friend2">
					<img src="img/img-forum/dodo.jpg" width="75px" height="75px"><a href="" class="af2">Dodo</a>
					<div class="but_Add">Add</div>
				</div>

				<div class="friend3">
					<img src="img/img-forum/kevin.jpg" width="75px" height="75px"><a href="" class="af3">Kevin</a>
					<div class="but_Add">Add</div>	
				</div>
				<div class="friend4">
					<img src="img/img-forum/adrian.jpg" width="75px" height="75px"><a href="" class="af4">Adrian</a>
					<div class="but_Add">Add</div>
				</div>
				<div class="friend1">
					<img src="img/img-forum/ahmad.jpg" width="75px" height="75px"><a href="" class="af1">Ahmad</a>
					<div class="but_Add">Add</div>
				</div>
				<div class="friend2">
					<img src="img/img-forum/dodo.jpg" width="75px" height="75px"><a href="" class="af2">Dodo</a>
					<div class="but_Add">Add</div>
				</div>

				<div class="friend3">
					<img src="img/img-forum/kevin.jpg" width="75px" height="75px"><a href="" class="af3">Kevin</a>
					<div class="but_Add">Add</div>	
				</div>
				<div class="friend4">
					<img src="img/img-forum/adrian.jpg" width="75px" height="75px"><a href="" class="af4">Adrian</a>
					<div class="but_Add">Add</div>
				</div> -->
			</div>
		</div>
	</div>
	
</div>

<footer class="second">
	<p>Copyright &copy jalan-jalan.com - All Rights Reserved.</p>
</footer>
</body>

</html>