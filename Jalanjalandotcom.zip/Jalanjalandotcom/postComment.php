<?php
include("connection.php");
include("session.php");

$content = $_POST['txtComment'];
$user = $_POST['txtUserID'];
$thread = $_POST['txtThreadID'];
$date = date("Y-m-d H:i:s");

mysql_query("INSERT INTO replies(ReplyContent,ReplyDate,ReplyThread,ReplyBy) VALUES 
             ('$content','$date','$thread','$user')") or die(mysql_error());

echo "<script>alert('Comment Added!');document.location='ThreadViewReplay.php?threadID=$thread';</script>";
?>